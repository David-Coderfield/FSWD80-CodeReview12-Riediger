<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package cr12_david_riediger_traveler
 */

get_header();
?>

	<section id="primary" class="content-area">
		<main id="main" class="site-main">

		<?php if ( have_posts() ) : ?>

			<header class="page-header">
				<h1 class="page-title">
					<?php
					/* translators: %s: search query. */
					printf( esc_html__( 'Search Results for: %s', 'cr12_david_riediger_traveler' ), '<span><mark>' . get_search_query() . '</span></mark>' );
					?>
				</h1>
			</header><!-- .page-header -->

			<?php
			/* Start the Loop */
			echo '<div class="row">';
			while ( have_posts() ) :
				the_post();

				?>
				<div class="col-12 col-sm-6 col-md-4 col-xl-3 mt-4">
					<div class="card h-100">
						<div class="embed-responsive embed-responsive-4by3">
							<img class="img-fluid embed-responsive-item card-img-top" src="<?php echo the_post_thumbnail_url(); ?>" alt="thumbnail">
						</div>
						<div class="card-body">
							<a href="<?php the_permalink(); ?>">
								<h1><?php the_title(); ?></h1>
							</a>
							<p>
								<?php 
								$content = get_the_content();
								$content = strip_tags($content);
								echo substr($content, 0, 90); 
								?>
								(...) <a href="<?php the_permalink() ?>">read more</a>
							</p>
						</div>
						<div class="card-footer">
							<p>
								Postet <?php echo get_the_date(); ?> by <a href="author/<?php the_author_link(); ?>"><?php the_author(); ?></a>
							</p>
						</div>
					</div>
				</div>
				<?php


				// get_template_part( 'template-parts/content', get_post_type() );

			endwhile;

			the_posts_navigation();

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif;
		echo '</div>'; /*.row*/
		?>

		</main><!-- #main -->
	</section><!-- #primary -->

<?php
get_sidebar();
get_footer();

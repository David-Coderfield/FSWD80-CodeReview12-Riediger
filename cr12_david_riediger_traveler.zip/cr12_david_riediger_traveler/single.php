<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package cr12_david_riediger_traveler
 */

get_header();
?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

		<?php
		while ( have_posts() ) :
				the_post();

				?>
					<div class="card h-100 w-100 mx-auto">
						<div class="card-header">
							<h1 class="text-center display-4"><u><?php the_title(); ?></u></h1>
						</div>
							<img class="img-fluid embed-responsive-item card-img-top" src="<?php echo the_post_thumbnail_url(); ?>" alt="thumbnail">
						<div class="card-body">
							<p>
								<?php 
								$content = get_the_content();
								echo $content; ?>
							</p>
						</div>
						<div class="card-footer">
							<p>
								Postet <?php echo get_the_date(); ?> by <a href="author/<?php the_author_link(); ?>"><?php the_author(); ?></a>
							</p>
						</div>
					</div>
				
				<div class="row">
					<div class="col-6">
						<h2><i class="fas fa-arrow-circle-left"></i></h2>
					</div>
					<div class="col-6 text-right">
						<h2><i class="fas fa-arrow-circle-right"></i></h2>
					</div>
				</div>
				<?php

				the_post_navigation();
				//comments
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;


				// get_template_part( 'template-parts/content', get_post_type() );

			endwhile; // End of the loop.
		?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_sidebar();
get_footer();

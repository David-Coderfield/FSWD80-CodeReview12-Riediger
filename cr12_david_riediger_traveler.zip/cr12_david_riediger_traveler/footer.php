<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package cr12_david_riediger_traveler
 */

?>

	</div><!-- #content -->
	</div><!-- .container -->

	<footer id="colophon" class="site-footer bg-dark text-light p-3">
		<div class="site-info">
			<p><a href="<?php echo esc_url( __( 'https://wordpress.org/', 'cr12_david_riediger_traveler' ) ); ?>">
				<?php
				/* translators: %s: CMS name, i.e. WordPress. */
				printf( esc_html__( 'Presented by %s', 'cr12_david_riediger_traveler' ), 'WordPress' );
				?>
			</a>
		</p>
				<p class="text-center">
				<?php
				/* translators: 1: Theme name, 2: Theme author. */
				printf( esc_html__( ' Theme: %1$s by %2$s', 'cr12_david_riediger_traveler' ), 'cr12_david_riediger_traveler', '<a href="http://underscores.me/">Underscores.me</a> </p> <p class="text-right">
					<span style="font-size:1.4rem"><i class="fab fa-facebook-square"></i> <i class="fab fa-instagram"></i> <i class="fab fa-twitter-square"></i> <i class="fab fa-youtube-square"></i> The end???</p></span>' );
				?>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
